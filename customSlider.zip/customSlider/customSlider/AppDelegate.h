//
//  AppDelegate.h
//  customSlider
//
//  Created by 徐虎威 on 2018/3/24.
//  Copyright © 2018年 徐虎威. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

